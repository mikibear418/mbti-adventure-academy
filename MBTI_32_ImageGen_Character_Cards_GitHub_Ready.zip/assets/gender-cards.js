/* 32 ImageGen fantasy academy character cards, 16 types × male/female.
 * Gender changes artwork only; it has no effect on test questions or scoring.
 * Image assets are local WebP files for reliable GitHub Pages / mobile loading.
 */
(function roleCardAddon(){
  'use strict';
  const KEY='mbti_role_art_gender_v1';
  const ORDER=['ISTJ','ISFJ','INFJ','INTJ','ISTP','ISFP','INFP','INTP','ESTP','ESFP','ENFP','ENTP','ESTJ','ESFJ','ENFJ','ENTJ'];
  const normalize=(value)=>value==='male'||value==='female'?value:'original';
  const original=(typeof HERO_IMAGES==='object' && HERO_IMAGES)?{...HERO_IMAGES}:{};
  let gender='original';
  try{gender=normalize(sessionStorage.getItem(KEY));}catch(error){}

  function makePortrait(type,variant){
    if(!ORDER.includes(type)||!['male','female'].includes(variant)) return '';
    return './assets/characters/'+type+'-'+variant+'.webp';
  }
  function applyImages(){
    if(typeof HERO_IMAGES!=='object')return;
    for(const type of ORDER){
      HERO_IMAGES[type]=gender==='original'?original[type]:makePortrait(type,gender);
    }
  }
  function picker(compact=false){
    const opts=[['female','女生角色'],['male','男生角色'],['original','不指定（原版）']];
    return `<fieldset class="gender-picker${compact?' compact':''}"><legend>選擇角色卡性別</legend><div class="gender-picker-options">${opts.map(([value,label])=>`<label class="gender-picker-item${gender===value?' active':''}"><input type="radio" name="mbti-role-gender" value="${value}" ${gender===value?'checked':''}><span>${label}</span></label>`).join('')}</div>${compact?'':'<p>同一人格提供男、女兩款精緻角色卡。這只是形象選擇，不影響測驗分數或人格判讀，可隨時切換。</p>'}</fieldset>`;
  }
  function decorate(){
    const view=state.view;
    if(view==='home'){
      const buttons=document.querySelector('.hero .buttons');
      if(buttons)buttons.insertAdjacentHTML('beforebegin',picker());
    }
    const grid=document.querySelector('.gallery-grid');
    if(grid&&(view==='home'||view==='gallery'))grid.insertAdjacentHTML('beforebegin',picker(true));
    if(view==='quiz'){
      const quiz=document.querySelector('.q-shell');
      if(quiz)quiz.insertAdjacentHTML('afterbegin',picker(true));
    }
    if(view==='result'){
      const image=document.querySelector('.result-visual');
      if(image){
        image.insertAdjacentHTML('beforebegin',picker());
        if(gender!=='original'){
          const target=image.querySelector('.result-id');
          if(target)target.insertAdjacentHTML('beforeend',`<div class="gender-role-note">✦ ${gender==='male'?'男生':'女生'}角色版本 · 與人格計分無關</div>`);
        }
      }
    }
    if(document.body)document.body.classList.toggle('role-gender-selected',gender!=='original');
  }
  function setGender(value){
    gender=normalize(value);
    try{sessionStorage.setItem(KEY,gender);}catch(error){}
    applyImages();
    render();
  }

  if(typeof module==='object'&&module.exports){module.exports={ORDER,makePortrait};}
  if(typeof document==='undefined'||typeof HERO_IMAGES==='undefined'||typeof state==='undefined'||typeof render!=='function')return;
  applyImages();
  const oldRender=render;
  render=function(){oldRender();decorate();};
  document.addEventListener('change',event=>{
    const target=event.target;
    if(target&&target.matches&&target.matches('input[name="mbti-role-gender"]'))setGender(target.value);
  });
  window.MBTIGenderCards={getGender:()=>gender,setGender,makePortrait,typeCount:ORDER.length};
  render();
})();

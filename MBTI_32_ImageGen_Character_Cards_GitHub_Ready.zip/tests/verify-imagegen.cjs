'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const crypto=require('node:crypto');
const root=path.resolve(__dirname,'..');
const types=['ISTJ','ISFJ','INFJ','INTJ','ISTP','ISFP','INFP','INTP','ESTP','ESFP','ENFP','ENTP','ESTJ','ESFJ','ENFJ','ENTJ'];
const js=fs.readFileSync(path.join(root,'assets/gender-cards.js'),'utf8');
new vm.Script(js);
const found=new Set();
for(const type of types){
 for(const gender of ['male','female']){
  const p=path.join(root,'assets','characters',`${type}-${gender}.webp`);
  const b=fs.readFileSync(p);
  assert.ok(b.length>12000,`Suspiciously small image ${p}`);
  assert.equal(b.toString('ascii',0,4),'RIFF',`Invalid WebP RIFF header: ${p}`);
  assert.equal(b.toString('ascii',8,12),'WEBP',`Invalid WebP signature: ${p}`);
  const fingerprint=crypto.createHash('sha256').update(b).digest('hex');
  assert.ok(!found.has(fingerprint),`Duplicate character file ${p}`);
  found.add(fingerprint);
  const portrait=path.join(root,'assets','portraits',`${type}-${gender}.webp`);
  assert.ok(fs.statSync(portrait).size>12000,`Missing print portrait ${portrait}`);
 }
}
assert.equal(found.size,32,'Expected 32 unique website artworks');
const mock={
 HERO_IMAGES:Object.fromEntries(types.map(type=>[type,'original-'+type])),
 state:{view:'home'},render(){},
 document:{querySelector(){return null;},addEventListener(){},body:{classList:{toggle(){}}}},
 window:{},sessionStorage:{getItem(){return null},setItem(){}},module:{exports:{}}
};
vm.runInNewContext(js,mock);
assert.equal(mock.module.exports.ORDER.length,16);
mock.window.MBTIGenderCards.setGender('female');
assert.equal(mock.HERO_IMAGES.ENFP,'./assets/characters/ENFP-female.webp');
mock.window.MBTIGenderCards.setGender('male');
assert.equal(mock.HERO_IMAGES.INTJ,'./assets/characters/INTJ-male.webp');
mock.window.MBTIGenderCards.setGender('original');
assert.equal(mock.HERO_IMAGES.INTJ,'original-INTJ');
console.log('PASS: 32 unique ImageGen-based WebP cards, 32 portrait cards, male/female/original selector.');

# MBTI 16 型人格冒險學院 — ImageGen 男女角色卡更新套件

本套件包含 **16 型人格 × 男、女各一款 = 32 款 ImageGen 奇幻學院風格角色卡**，與原版一致的金色典藏邊框、星象符號、學院服裝。角色主視覺來源為 ImageGen 生成圖片；為了避免圖片文字不準確，每張圖片的底部標籤區已重新排版，保留正確的 MBTI 四碼與性別角色選項。

## 內容

- `assets/characters/` — **32 張網站版 4:3 WebP**，對應原本網站的橫式角色圖展示（即時切換用）。
- `assets/portraits/` — **32 張直式典藏卡 WebP**，保留完整肖像與金色邊框，可列印或後續設計使用。
- `assets/gender-cards.js` — 自動對應男女角色圖，不影響原版 80 題或四個維度的計分；「不指定（原版）」仍保留原圖。
- `.github/workflows/validate.yml`、`tests/verify-imagegen.cjs` — 持續檢查 80 題、16 型、原始圖像、32 張獨立男女圖像及 QR 海報。
- `MBTI-32-cards-contact-sheet.jpg` — 32 款直式角色圖總覽，供手機及電腦快速核對。

## 導入 GitHub 專案

目標 GitHub 專案：<https://github.com/mikibear418/mbti-adventure-academy>

1. 將本套件解壓到該專案**根目錄**，保留資料夾結構；覆蓋 `assets/gender-cards.js`、`.github/workflows/validate.yml`，合併新增的圖片與 `tests` 資料夾，不要覆蓋或刪除原有 `index.html`、`poster.html` 和 QR Code。
2. 使用 GitHub Desktop 或 Git 將變更一次提交並推送到 `main`，讓 Pages 自動重新部署。`assets/gender-cards.css` 原版可沿用，不需變更。
3. 在網站首頁、圖鑑、測驗進行中、結果頁切換「女生角色／男生角色／不指定（原版）」；檢查卡片圖片、下載 PNG 與手機版是否正常。
4. GitHub **Actions** 應出現 `Validate MBTI Academy Website` 及 `Publish MBTI Adventure Academy` 兩個成功項目；網站網址：<https://mikibear418.github.io/mbti-adventure-academy/>。

> 注意：這些藝術性別造型是角色外觀選擇，與心理測驗結果無關。本工具僅用於國中自我探索教學，不應作為心理診斷或分班依據。
